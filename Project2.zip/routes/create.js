const express = require('express')
const router = express.Router();

router.get('/', async(req, res) => {
    // const id = await req.db.createContact();
    // console.log('create.js: id:', id);
    res.render('create', {});
});

router.post('/', async (req, res) => {
    console.log('create.js: req.body.id:', req.body.id);
    // const contact = await req.db.findContact(req.body.id);
    // if(!contact) {
    //     res.writeHead(404);
    //     res.end();
    //     return;
    // }
    console.log('create.js: Pressed Add Button');
    console.log('create.js: req.body:', req.body);
    const id = await req.db.createContact(req.body);
    console.log('create.js: id:', id);
    // const contact = await req.db.findContact(id);
    // console.log('create.js: contact:', contact);
    // const contact = await req.db.findContact(id);
    // await req.db.recordContact(contact, contact.id);
    await req.db.recordContact(req.body, id);
});

module.exports = router;